{
    "name":"Selección de comprobante desde el Carrito de Compras",
    "depends":["web","website_sale","gestionit_pe_fe"],
    "data":[
        "template.xml",
        "assets.xml",
        "views.xml"
    ]
}